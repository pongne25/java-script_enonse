import logo from './logo.svg';
import './App.css';
import { useEffect, useReducer } from "react";

function App() {

   const data=[
   {
      id: 293293,
      date: "2022-09-12T12:34:45",
      question: "How to center a div?",
      status: "active",
      answers: [
        {
          id: 3239213,
          answer: "Answer 1",
          score: -3
        },
        {
          id: 98392230,
          answer: "Use `text-align: center`",
          score: 2
        },
        {
          id: 98943483,
          answer: "The div wrapper should have display flex",
          score: 19
        },
        {
          id: 766329392,
          answer:
            "Some representative placeholder content for the second slide of the carousel.",
          score: 1
        }
      ],
      tags: ["HTML", "CSS"],
      score: 23
    },
    {
      id: 837273,
      date: "2023-01-03T04:14:37",
      question: "How to install NodeJS?",
      status: "delete",
      answers: [
        {
          id: 7177112,
          answer: "NodeJS is part of JS",
          score: 1
        },
        {
          id: 2567723,
          answer: "Visit their site at nodejs.org",
          score: 7
        },
        {
          id: 6612122,
          answer: "Can we say, this question is stupid",
          score: -5
        },
        {
          id: 9001212,
          answer: "Visit the official website nodejs.org",
          score: 0
        }
      ],
      tags: ["JS", "NodeJS", "Engine"],
      score: 3
    },
    {
      id: 122181,
      date: "2022-11-17T14:08:12",
      question: "useEffect in React triggered twice",
      status: "active",
      answers: [
        {
          id: 2039934,
          answer: "Maybe you call the callback function twice",
          score: 1
        },
        {
          id: 1288343,
          answer:
            "If you have a button, make sure it does not trigger the callback function",
          score: 10
        },
        {
          id: 5949283,
          answer:
            "Sometimes React.Strict trigger your app twice, for testing purpose (only in dev)",
          score: 23
        },
        {
          id: 8288823,
          answer: "no clean function",
          score: 1
        }
      ],
      tags: ["React", "JS", "JavaScript", "React-DOOM"],
      score: 30
    }
]

const copy1=""
const initialState = {
    data1:data,
    copy: copy1,
  }
 
 const reducer = (state, action) => {
    switch(action.type){
      case "DONE":
        return {data1:action.done}

       case "PLIS":
        return{...state,data1:state.data1.map((a)=>
          a.id===action.id?{...a,score:a.score+1}:a),

        copy:state.data1.map((a)=>a.id===action.id?{...a,score:a.score+1}:a)};


      case "MWENS":
        return{...state,data1:state.data1.map((a)=>
          a.id===action.id?{...a,score:a.score-1}:a),
        copy:state.data1.map((a)=>a.id===action.id?{...a,score:a.score-1}:a)};


       case "REPPLIS":
      return{...state,data1:state.data1.map((a)=>
        a.id===action.id?
        {...a,answers :a.answers.map((r)=>r.id===action.id2?
         {...r,score:r.score+1}:r)}:a)};

      case "REPMWENS":
        return{...state,data1:state.data1.map((a)=>a.id===action.id?
          {...a,answers :a.answers.map((r)=>r.id===action.id2?
           {...r,score:r.score-1}:r)}:a)};

      case "EFASE1":
        return{...state,data1:state.data1.filter((a)=>a.id !== action.id),}

      case "EFASE":
        return{...state,data1:state.data1.map((a)=>a.id === action.id?
          {...a, answers:a.answers.filter((it)=>
            it.id !== action.id2)}:a)};

        //pou champ select yo

        case "All"://all
          if(action.tri==="Hot"){
            const s1a=[...data].sort((i,j)=>j.answers.length-i.answers.length);
            return {...state,data1:s1a}
          }
          else if(action.tri==="Popular"){
            const s2a=[...data].sort((i,j)=>j.score-i.score);
            return {...state,data1:s2a}
          }
           else{
            const s3a=[...data].sort((i,j)=>new Date(j.date)-new Date(i.date));
            return {...state,data1:s3a}
          }

          case "Active"://active
          if(action.tri==="Hot"){
             const s=[...data].filter((i)=>i.status==='active');
            const s1b=[...s].sort((i,j)=>j.answers.length-i.answers.length);
            return {...state,data1:s1b}
          }

            else if(action.tri==="Popular"){
            const s=[...data].filter((i)=>i.status==='active');
            const s2b=[...s].sort((i,j)=>j.score-i.score);
            return {...state,data1:s2b}
          }
          else{
             const s=[...data].filter((i)=>i.status==='active');
            const s3b=[...s].sort((i,j)=>new Date(j.date)-new Date(i.date));
            return {...state,data1:s3b}
          }

          case "Inactive"://inactive
          if(action.tri==="Hot"){
             const s=[...data].filter((i)=>i.status==='delete');
            const s1c=[...s].sort((i,j)=>j.answers.length-i.answers.length);
            return {...state,data1:s1c}
          }
          else if(action.tri==="Popular"){
            const s=[...data].filter((i)=>i.status==='delete');
            const s2c=[...s].sort((i,j)=>j.score-i.score);
            return {...state,data1:s2c}
          }
          else{
             const s=[...data].filter((i)=>i.status==='delete');
            const s3c=[...s].sort((i,j)=>new Date(j.date)-new Date(i.date));
            return {...state,data1:s3c}
          }

      default:
        return state
    }
  }

const [state, dispatch] = useReducer(reducer, initialState)
useEffect(()=>{
  dispatch({type:"DONE",done:data})
},[]
);
const filter1= ["All", "Active", "Inactive"];
const tri1= ["Recent", "Popular", "Hot"];


let filtrer = document.querySelector("#filtrer");
let trier = document.querySelector("#trier");


     function dispatching(value1,value2){
  dispatch({type:"DONE",data1:state.copy})
  dispatch({ type: value1, tri:value2 })
}



  return (


    <div style={{marginLeft:"25px"}}>

      {state.data1.map((i,j)=>{
        return(

        <div>


            <h2 > KESYON : {i.question} </h2>
            <span>dat : {i.date}</span><br/><br/>

              
            <button onClick={() => (dispatch({type: "PLIS", id:i.id}))}>PLiS</button> 
             <label id={i.id}> PWEN : {i.score} </label> 
            <button onClick={() =>  dispatch({type: "MWENS", id:i.id})}>MWENS</button>
            <br/>
            <button  onClick={() => {
                dispatch({ type: "EFASE1", id: i.id });
              }}>EFASE</button>
             <hr/>

            
              <strong>TOTAL REPONS : {i.answers.length}</strong>
           
           {
              i.answers?.map((r,e)=>{
                
                return(
                    <div>

                        <h3> Repons {e} :{r.answer} </h3>
                         <button onClick={() => (dispatch({type: "REPPLIS", id2:r.id,id:i.id}))}>PLiS</button> 
             <label id={r.id}> PWEN : {r.score} </label> 
            <button onClick={() =>  dispatch({type: "REPMWENS", id2:r.id,id:i.id})}>MWENS</button>
            <br/>
            <button onClick={() => {
                      dispatch({
                        type: "EFASE",
                        id2: r.id,
                        id: i.id
                      });
                    }}>EFASE</button>           
                         <br/>
                       <br/>
                    </div>

                  )
              })
          }

          <ul>
          <li>Langaj : {i.tags}</li>
          </ul>
       
    
 </div>)
      
    })}

    
     <label> Filtrer </label>
       <select id="filtrer">
            {filter1.map((sec) => {
              return (
                <option id="op" value={sec}>
                  {sec}
                </option>
              );
            })}
          </select>
          {filtrer !== null ? filtrer.setAttribute("selected", "selected") : ""}
          {trier !== null ? trier.setAttribute("selected", "selected") : ""}
         
          <label> triyaj </label>
          <select id="trier">
            {tri1.map((sec) => {
              return (
                <option id="opp" value={sec}>
                  {sec}
                </option>
              );
            })}
          </select>

          <button
            onClick={() =>
              dispatching(filtrer.value,trier.value)
            }
          >
            Submit
          </button>

     
      <br/>

      <br/><br/><br/>
        <hr/>
   

    </div>
  )
}
 
export default App;
